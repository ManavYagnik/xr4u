import React from 'react';
import Blogs from '../Blogs';

const BlogPage = () => {
  return (
    <div className=''>
      <Blogs />
    </div>
  );
}

export default BlogPage;
